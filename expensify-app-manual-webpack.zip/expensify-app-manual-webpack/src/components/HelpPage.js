import React from 'react'

const HelpPage = () => (
  <div>
    This is the help component.
  </div>
);

export default HelpPage;